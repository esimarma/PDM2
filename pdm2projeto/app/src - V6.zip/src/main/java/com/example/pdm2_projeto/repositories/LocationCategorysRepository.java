package com.example.pdm2_projeto.repositories;

public class LocationCategorysRepository {
}
