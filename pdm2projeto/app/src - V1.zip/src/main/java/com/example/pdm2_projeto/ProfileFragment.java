package com.example.pdm2_projeto;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class ProfileFragment extends Fragment {

    private FirebaseAuth auth;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        auth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = auth.getCurrentUser();

        TextView textNotLoggedIn = view.findViewById(R.id.text_not_logged_in);
        Button buttonLogin = view.findViewById(R.id.button_login);

        if (currentUser != null) {
            textNotLoggedIn.setText("Logged in as " + currentUser.getEmail());
            buttonLogin.setText("Logout");
            buttonLogin.setOnClickListener(v -> {
                auth.signOut();
                startActivity(new Intent(getContext(), LoginActivity.class));
                getActivity().finish();
            });
        } else {
            buttonLogin.setOnClickListener(v -> {
                startActivity(new Intent(getContext(), LoginActivity.class));
            });
        }

        return view;
    }
}
